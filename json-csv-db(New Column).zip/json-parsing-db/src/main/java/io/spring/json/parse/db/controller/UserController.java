package io.spring.json.parse.db.controller;

import java.io.IOException;
import java.util.List;
import java.io.FileWriter;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import io.spring.json.parse.db.dto.User;
import io.spring.json.parse.db.service.UserService;

@RestController
public class UserController {

	private final UserService userService;

	public UserController(UserService userService) {

		this.userService = userService;
	}

	@GetMapping("/save-to-csv")
	public String saveToCsv() {

		List<User> users = userService.getUserFromApi();
		try (FileWriter writer = new FileWriter("C:\\Users\\ankit.kumarsingh\\Desktop\\Ankit2.csv")) {
			writer.append("postId,id,name,email,body");
			for (User user : users) {
				writer.append(String.format("%d,%d.%s,%s.%s\n", user.getPostId(), user.getId(), user.getName(),
						user.getEmail(), user.getBody()));
			}
			writer.flush();
			return "Data saved in the CSV file ";

		} catch (IOException e) {
			e.printStackTrace();
			return "Error saving data into the database in the CSV file";
		}
	}

	@GetMapping("/save-to-database")
	public String saveToDatabase() {
		List<User> users = userService.getUserFromApi();
		userService.saveUserToDatabase(users);

		return "Data save to the database ";

	}

	@GetMapping("/fetch-data")
	public ResponseEntity<String> fetchData() {
		userService.fetchDataUsingNativeQuery();
		return ResponseEntity.ok("New Column added to the table ");
	}

}
