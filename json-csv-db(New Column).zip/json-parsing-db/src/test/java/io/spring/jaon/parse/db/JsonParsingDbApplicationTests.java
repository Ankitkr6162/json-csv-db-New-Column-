package io.spring.jaon.parse.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonParsingDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
